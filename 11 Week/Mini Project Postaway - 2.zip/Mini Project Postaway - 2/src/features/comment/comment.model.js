export default class CommentModel {
  constructor(content, id) {
    this.content = content
    this._id = id
  }
}