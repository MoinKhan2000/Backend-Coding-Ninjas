// Load all the environment variables.
import dotenv from "dotenv"
dotenv.config()