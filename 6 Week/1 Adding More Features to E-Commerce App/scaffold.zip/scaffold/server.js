import server from "./index.js";

server.listen(4000, () => {
  console.log("server is listening on port 4000");
});
